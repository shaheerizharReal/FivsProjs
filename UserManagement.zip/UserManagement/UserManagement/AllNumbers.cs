﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserManagement
{
    public partial class AllNumbers : Master
    {
        public AllNumbers()
        {
            InitializeComponent();
            using (var streamReader = new StreamReader(@"C:\Files\Details.txt"))
            {
                while (!streamReader.EndOfStream)
                {
                    var line = streamReader.ReadLine();
                    var values = line.Split('\t');
                    var rowIndex = dataGridView1.Rows.Add();
                    for (int i = 0; i < values.Length; i++)
                    {
                        dataGridView1.Rows[rowIndex].Cells[i].Value = values[i];
                    }
                }
            }
        }
    }
}
