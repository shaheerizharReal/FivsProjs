﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserManagement
{
    public partial class Form1 : Master
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                 MessageBox.Show("All Feilds are Required");
                 return;
            }
            else
            {
                if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    if (ValidateChildren(ValidationConstraints.Enabled))
                    {
                        string fileName = @"C:\Files\Details.txt";

                        try
                        {

                            // Create a new file     
                            //string insert = textBox1.Text + " " + textBox2.Text + " " + textBox3.Text;
                            string insert = textBox3.Text;
                            File.AppendAllText(fileName, insert + Environment.NewLine);
                            MessageBox.Show("Successfully Inserted");
                            textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = "";

                        }
                        catch (Exception Ex)
                        {
                            Console.WriteLine(Ex.ToString());
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            this.Hide();

            AllNumbers numbers = new AllNumbers();
            numbers.Show();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {

        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
           
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text) || textBox3.Text == "")
            {
                e.Cancel = true;
                textBox3.Focus();  
                errorProvider1.SetError(textBox3, "All Feilds are Required!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(textBox3, "");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text) || textBox2.Text == "")
            {
                e.Cancel = true;
                textBox2.Focus();  
                errorProvider1.SetError(textBox2, "All Feilds are Required!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(textBox2, "");
            }
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || textBox1.Text == "")
            {
                e.Cancel = true;
                textBox1.Focus();  
                errorProvider1.SetError(textBox1, "All Feilds are Required!");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(textBox1, null);
            }
        }
    }
}
