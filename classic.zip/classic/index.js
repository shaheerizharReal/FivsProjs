import Classic from './Classic';
import image from './preview.png';

export const Image = image;
export default Classic;
