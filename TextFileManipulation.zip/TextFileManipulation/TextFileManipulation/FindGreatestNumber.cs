﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextFileManipulation
{
    public class FindGreatestNumber
    {
        public int GreatestNumber(string textFilePath)
        {
            string[] lines = File.ReadAllLines(textFilePath);
            string[] authorsList;
            int max = 0;
            try
            {
                foreach (string line in lines)
                {
                    authorsList = line.Split(' ');
                    max = Convert.ToInt32(authorsList[0]);
                    for (int i = 1; i < authorsList.Length; i++)
                    {
                        if (authorsList[i] != null && !authorsList[i].Equals("") && !authorsList[i].Equals(" "))
                        {
                            if (Convert.ToInt32(authorsList[i]) > max)
                            {
                                max = Convert.ToInt32(authorsList[i]);
                            }
                        }

                    }
                    Console.WriteLine("LArgest Number : {0}", max);
                    Console.WriteLine("==========================");
                    //Array.Clear(authorsList, 0, authorsList.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Details:  {0}", ex);
            }
           
            return 1;
        }
    }
}
