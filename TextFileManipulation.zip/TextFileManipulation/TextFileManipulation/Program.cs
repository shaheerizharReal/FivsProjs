﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextFileManipulation
{
    class Program
    {
        static void Main(string[] args)
        {
            FindGreatestNumber fgn = new FindGreatestNumber();
            string path = @"C:\Files\numbers.txt";
            fgn.GreatestNumber(path);
            Console.ReadKey();
        }
    }
}
